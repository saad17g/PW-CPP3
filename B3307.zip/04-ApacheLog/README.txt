Ce dossier contient l'ensemble des fichiers du TP4 pour le binôme B3307 : Saad GUESSOUS et Jules DUCANGE

Pour compiler le programme et générer l'exécutable, utilisez la commande make en étant dans ce répertoire.

L'exécutable se trouvera dans le répertoire /bin/

Pour supprimer les .o ainsi que l'exécutable, utilisez la commande make clean, en étant dans ce répertoire.

Les tests s'exécutent depuis le dossier tests.

Pour exécuter un test en particulier, utilisez la commande ./test.sh [nomTest]
Pour exécuter tous les tests, utilisez la commande ./mktest.sh

Le fichier .pdf "CR TP4 B3307" contient les spécifications détaillées vis-à-vis du programme.

Le fichier "specifications" détaille les différents tests selon l'Option choisie.